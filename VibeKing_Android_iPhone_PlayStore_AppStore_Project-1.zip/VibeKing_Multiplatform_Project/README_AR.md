# Vibe King — Android + iPhone

هذه حزمة تجهيز للتطبيق الحالي **Vibe King V13** (الاسم + تاريخ الميلاد، بدون بريد وكلمة مرور) لتشغيله على Android وiPhone.

## Android / Google Play
- المشروع موجود داخل `Android/`.
- `compileSdk = 36` و `targetSdk = 36`، وهو مناسب لمتطلبات Google Play الحالية للتطبيقات الجديدة ابتداءً من 31 أغسطس 2026.
- افتح مجلد `Android/` في Android Studio.
- نفّذ Gradle Sync ثم أنشئ **Signed AAB** من Build > Generate Signed Bundle / APK.
- لا أستطيع من هذه البيئة إنشاء توقيع Play أو رفع التطبيق إلى حسابك في Play Console.

## iPhone / App Store
- المشروع موجود داخل `iOS/VibeKing/`.
- افتح `VibeKing.xcodeproj` على Mac مع Xcode.
- اختر Team الخاص بحساب Apple Developer ثم Build/Archive.
- ارفع النسخة إلى App Store Connect عبر Xcode ثم أرسلها للمراجعة.
- متطلبات Apple الحالية تتطلب بناء التطبيقات المرفوعة إلى App Store Connect باستخدام Xcode 26 أو أحدث وSDK iOS 26 أو أحدث.

## مهم قبل النشر الحقيقي
النسخة الحالية تحفظ الحساب والمحتوى المحلي داخل التطبيق/الجهاز. لكي يصبح التطبيق اجتماعيًا حقيقيًا بين عدة أجهزة، نحتاج Backend وقاعدة بيانات ومصادقة حقيقية ومخزن ملفات.

كذلك يجب أن تكون الأفلام والكتب والصور والفيديوهات التي تنشرها مرخّصة لك قانونيًا.
